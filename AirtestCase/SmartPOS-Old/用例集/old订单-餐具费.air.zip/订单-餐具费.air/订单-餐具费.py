# -*- encoding=utf8 -*-
# 简餐增加餐具费
__author__ = "Administrator"

from airtest.core.api import *

auto_setup(__file__)
touch(Template(r"tpl1546074092173.png", record_pos=(-0.339, -0.237), resolution=(1366, 768)))
touch(Template(r"tpl1546076656930.png", record_pos=(-0.335, 0.01), resolution=(1366, 768)))

#touch(Template(r"tpl1546071853905.png", record_pos=(-0.224, 0.01), resolution=(1366, 768)))
touch(Template(r"tpl1546071874112.png", record_pos=(0.252, -0.144), resolution=(1366, 768)))
assert_exists(Template(r"tpl1546071908607.png", record_pos=(0.354, -0.085), resolution=(1366, 768)), "验证下单打包费是否已增加")
touch(Template(r"tpl1546071932023.png", record_pos=(0.283, 0.222), resolution=(1366, 768)))



assert_exists(Template(r"tpl1546077058543.png", record_pos=(0.209, -0.167), resolution=(1366, 768)), "请填写测试点")

touch(Template(r"tpl1546071972568.png", record_pos=(0.313, 0.121), resolution=(1366, 768)))
sleep(2.0)
touch(Template(r"tpl1546072136278.png", record_pos=(0.161, -0.236), resolution=(1366, 768)))
assert_exists(Template(r"tpl1546072284601.png", record_pos=(0.031, -0.067), resolution=(1366, 768)), "订单支付成功打包费订单总价为21元")


